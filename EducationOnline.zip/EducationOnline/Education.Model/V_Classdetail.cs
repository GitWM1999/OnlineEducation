﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Education.Model
{
    public class V_Classdetail:ClassList
    {
        public string Teacher_Name { get; set; }
    }
}
