﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Education.Model
{
    public class TeachersInfor
    {
        public int Teacher_Id { get; set; }
        public string Teacher_AccountNumber { get; set; }
        public string Teacher_Pwd { get; set; }
        public string Teacher_Name { get; set; }
        public string Teacher_Icon { get; set; }
        public string Teacher_PhoneNumber { get; set; }
        public string Teacher_Email { get; set; }
        public string Teacher_intro { get; set; }
        public int Teacher_Status { get; set; }
        public int Teacher_IsDelete { get; set; }
        

    }
}
