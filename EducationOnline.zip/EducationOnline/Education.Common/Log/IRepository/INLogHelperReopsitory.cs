﻿using System;

namespace Education.Common
{
    //NLogHelper接口
    public interface INLogHelperReopsitory
    {
        void LogError(Exception ex);
    }
}
