﻿using Castle.DynamicProxy;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using NLog;
using System;
using System.Text;

namespace Education.Common
{
    public class NLogHelperReopsitory : INLogHelperReopsitory
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly ILogger<NLogHelperReopsitory> _logger;
        //每创建一个Logger都会有一定的性能损耗，所以定义静态变量
        private static Logger logger;

        #region 初始化
        public NLogHelperReopsitory(IHttpContextAccessor httpContextAccessor, ILogger<NLogHelperReopsitory> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
        }

        static NLogHelperReopsitory()
        {
            logger = LogManager.GetCurrentClassLogger();
        }
        #endregion

        #region Info 记录日志
        /// <summary>
        /// 记录日志
        /// </summary>
        /// <param name="msg"></param>
        public static void Info(string msg, Exception ex = null)
        {
            if (ex == null)
            {
                logger.Info(msg);
            }
            else
            {
                logger.Info(ex, msg);
            }
        }
        #endregion

        #region Error 记录错误日志
        /// <summary>
        /// 记录错误日志
        /// </summary>

        public static void Error(string msg, Exception ex = null)
        {
            if (ex == null)
            {
                logger.Error(msg);
            }
            else
            {
                logger.Error(ex, msg);
            }
        }
        public void LogError(Exception ex)
        {
            //日志消息
            LogMessage logMessage = new LogMessage();
            //IP
            logMessage.IpAddress = _httpContextAccessor.HttpContext.Request.Host.Host;
            //是否为内部异常
            if (ex.InnerException != null)
            {
                logMessage.LogInfo = ex.InnerException.Message;
            }
            else
            {
                logMessage.LogInfo = ex.Message;
            }
            //跟踪信息
            logMessage.StackTrace = ex.StackTrace;
            //操作人
            logMessage.OperationName = "admin";
            //记录错误日志
            _logger.LogError(ErrorFormat(logMessage));
        }
        /// <summary>
        /// 生成报错信息
        /// </summary>
        /// <param name="logMessage"></param>
        /// <returns></returns>
        public static string ErrorFormat(LogMessage logMessage)
        {
            StringBuilder strError = new StringBuilder();
            strError.Append("操作人: " + logMessage.OperationName + "\r\n");
            strError.Append("Ip:" + logMessage.IpAddress + "\r\n");
            strError.Append("错误内容: " + logMessage.LogInfo + "\r\n");
            strError.Append("跟踪:" + logMessage.StackTrace + "\r\n");
            return strError.ToString();
        }
        #endregion

        #region Debug 记录调试日志
        /// <summary>
        /// 记录调试日志
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="ex"></param>
        public static void Debug(string msg, Exception ex = null)
        {
            if (ex == null)
            {
                logger.Debug(msg);
            }
            else
            {
                logger.Debug(ex, msg);
            }
        }
        #endregion

        #region Fatal 严重致命错误日志
        /// <summary>
        /// 严重致命错误日志
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="ex"></param>
        public static void Fatal(String msg, Exception ex = null)
        {
            if (ex == null)
            {
                logger.Fatal(msg);
            }
            else
            {
                logger.Fatal(ex, msg);
            }
        }
        #endregion

        #region Warn 警告日志
        /// <summary>
        /// 警告日志
        /// </summary>
        /// <param name="msg"></param>
        public static void Warn(String msg)
        {
            try
            {
                logger.Warn(msg);
            }
            catch { }
        }
        #endregion

        #region 生成日志消息的构造函数
        /// <summary>
        /// 生成基础的日志消息
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static LogMessage GetLogMessage(HttpContext context)
        {
            //日志消息
            LogMessage loggerMessage = new LogMessage()
            {
                IpAddress = context.Request.Host.ToString(),
                LogInfo = "",
                OperationName = "",
                RequestBody = context.Request.Body.ToString(),
                RequestType = context.Request.Method,
                RequestUrl = context.Request.Path,
                StackTrace = "",
                StatusCode = context.Response.StatusCode.ToString()
            };
            return loggerMessage;
        }
        /// <summary>
        /// 生成基础日志
        /// </summary>
        /// <param name="loggerMessage"></param>
        public static string GetLog(LogMessage loggerMessage)
        {
            string message =
                "IP:" + loggerMessage.IpAddress + Environment.NewLine +
                "请求体:" + loggerMessage.RequestBody + Environment.NewLine +
                "请求路径:" + loggerMessage.RequestUrl + Environment.NewLine +
                "请求类型:" + loggerMessage.RequestType + Environment.NewLine +
                "返回结果:" + loggerMessage.StatusCode + Environment.NewLine;
            return message;
        }

        /// <summary>
        /// 生成AOP日志
        /// </summary>
        public static void AddAOPLog(IInvocation invocation, string result, bool way)
        {
            Log aopNlog = new Log();
            aopNlog.MethodName = invocation.Method.Name;
            aopNlog.ReturnType = invocation.Method.ReturnType.Name;
            aopNlog.ReturnUrl = invocation.TargetType.FullName;
            aopNlog.ReturnResult = result;

            //日志写入
            if (way == true)
            {
                string message =
                "方法名:" + invocation.Method.Name + Environment.NewLine +
                "返回类型:" + invocation.Method.ReturnType.Name + Environment.NewLine +
                "返回路径:" + invocation.TargetType.FullName + Environment.NewLine +
                "返回结果:" + result;
                NLogHelperReopsitory.Debug(message);
            }
            //数据库写入
            else
            {
               // string sql = "insert into Log values(@MethodName,@ReturnType,@ReturnUrl,@ReturnResult)";
                //int i = _logRepository.Execute(sql, new { @MethodName = aopNlog.MethodName, @ReturnType = aopNlog.ReturnType, @ReturnUrl = aopNlog.ReturnUrl, @ReturnResult = aopNlog.ReturnResult });
            }
        }

        #endregion

    }
}
