﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Education.Common
{
    public class DbConfig
    {
        public static string UseDB { get; set; }
        public static string SqlServerConStr { get; set; }
        public static string MySqlConStr { get; set; }
    }
}
