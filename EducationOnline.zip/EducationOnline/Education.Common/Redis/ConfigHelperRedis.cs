﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Education.Common
{
    public class ConfigHelperRedis
    {
        public static string _conn = "";

        public static string _name = "";

        public static int _db = 0;

    }
}
