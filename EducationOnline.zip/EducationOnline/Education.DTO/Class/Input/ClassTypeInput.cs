﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Education.DTO
{
    /// <summary>
    /// 一级分类的添加
    /// </summary>
    public  class ClassTypeInput
    {
        public string Type_Name { get; set; }     // 一级分类名称
    }
}
