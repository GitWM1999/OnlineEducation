﻿using Education.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Education.DTO.Class
{
    public class V_ClassdetailInput: ClassList
    {
        public string Teacher_Name { get; set; }
    }
}
