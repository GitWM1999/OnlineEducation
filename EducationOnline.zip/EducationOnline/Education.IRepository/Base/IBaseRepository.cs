﻿using System;

namespace Education.IRepository
{
    public interface IBaseRepository
    {
        
    }
}
